//Amy Wickham 121785021
package com.example.meditime.repository;

import com.example.meditime.model.Report;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportRepository extends JpaRepository<Report, Long> {
}